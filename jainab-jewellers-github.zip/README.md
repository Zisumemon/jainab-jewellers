# Jainab Jewellers Website

Hosted with 💎 GitHub Pages.

Admin Panel for managing stock, purchase, sale, and invoice.